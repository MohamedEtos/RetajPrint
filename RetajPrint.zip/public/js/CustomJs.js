$(document).ready(function() {
    $('#smoth').delay(5000).slideUp(800);
    $('[placeholder]').focus(function() {

            $(this).attr('data-text', $(this).attr('placeholder'));
            $(this).attr('placeholder', '')

        }).blur(function() {
            $(this).attr('placeholder', $(this).attr('data-text'))
        })
        // end for hide placeholder if foucs


 


        //show and hide divs with font awosme

        $(".toggle").click(function(){
            $(this).toggleClass("selected").parent().next(".panel-b").toggle(200);
            if($(this).hasClass("selected")){
                $(this).html('<i class="fa fa-plus" ></i>');
            }else{
                $(this).html('<i class="fa fa-minus" ></i>')
            }
        })



});


