<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

class CustomerData extends Migration
{



    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // DB::unprepared('  insert this code in sql php my admin will be work
        // CREATE TRIGGER Restore
        // BEFORE DELETE ON customerdeleted
        // FOR EACH ROW
        // INSERT INTO customerdata(id,cname,meter,EMP,WhoEdited,created_at,updated_at)
        // VALUES(old.id,old.cname,old.meter,old.EMP,old.WhoDelete,old.created_at,old.updated_at)
        // ');



        Schema::create('CustomerData', function (Blueprint $table) {
            $table->id();
            $table->string('cname');
            $table->string('meter');
            $table->string('EMP');
            $table->string('WhoEdited')->default('Not modified yet');
            $table->timestamps();
        });


    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('CustomerData');
    }
}
