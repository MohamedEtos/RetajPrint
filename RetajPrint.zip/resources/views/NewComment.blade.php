@extends('layouts.master')
@section('Comment')
<div class="container mt-5">
    <div class="row">
      <div class="col-12">
        @if (Session::has('CommentSuc'))
            <div class="alert alert-success" id="smoth"role="alert">
                {{Session('CommentSuc')}}
            </div>
        @endif
       <form action="{{url('Comment/StoreComment')}}" method="POST">
        @csrf
        <div class="form-group">
            <label for="exampleInputEmail1">New Comment</label>
            <input name="newcomment" type="text" class="form-control" id="newcomment"  aria-describedby="newcomment" placeholder="Type Comment Here">
            @error('newcomment')
            <small id="newcomment" class="form-text  text-danger">{{'* '.$message}}</small>
            @enderror
        </div>
        <button type="submit" class="btn btn-sm btn-primary">Save Comment</button>
       </form>
      </div>

    </div>
</div>
@endsection
