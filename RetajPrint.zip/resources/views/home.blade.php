@extends('layouts.master')

@section('content')


<div class="container main_dash mt-5">
    <div class="row">
        <div class="col-md-3">
            <div class="total members">
                <h6>{{$countCustomers}}</h6>
                <i class=" fa fa-users user_icon"></i>
                <h6>Number Of Clients </h6>
                <a href="{{url('Orders/All')}}" class="text-reset">
                    <div class="footer_panel">
                        more info <i class="fas fa-arrow-alt-circle-right"></i>
                    </div>
                </a>
            </div>
        </div>


        <div class="col-md-3">
            <div class="total pending">
                <h6>{{$countOrders}}</h6>
                <i class="fas fa-chart-line user_icon"></i>
                <h6>Printed Orders</h6>
                <a href="{{url('Orders/All')}}" class="text-reset">
                    <div class="footer_panel">
                        more info <i class="fas fa-arrow-alt-circle-right"></i>
                    </div>
                </a>
            </div>
        </div>
        <div class="col-md-3">
            <div class="total item">
                <h6>{{$countMeter}} </h6>
                <i class="fas fa-ruler user_icon"></i>
                <h6>Total Meter Printing</h6>
                <a href="{{url('Orders/totalmeter')}}" class="text-reset">
                    <div class="footer_panel">
                        more info <i class="fas fa-arrow-alt-circle-right"></i>
                    </div>
                </a>
            </div>
        </div>
        <div class="col-md-3">
            <div class="total comments">
                <h6>{{$countDeleted}}</h6>
                <i class=" fa  fa-trash user_icon"></i>
                <h6>Total Orders Deleted</h6>
                    <a href="{{url('Orders/RecycleBin')}}" class="text-reset">

                    <div class="footer_panel">
                        more info <i class="fas fa-arrow-alt-circle-right"></i>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>




<div class="container ">
    <div class="row ">
        <div class="col-md-6">
            <div class="panel panel-default lastes lastes_sky">
                <div class="panel-heading panel-h">
                    <i class="fa fa-users"></i>
                    <span>Lastes Orders</span>
                    <span class="plus toggle fa-pull-right">
                        <i class="fa fa-minus  "></i>
                    </span>
                </div>
                <div class="panel-body panel-b">

                        <div class="row">
                            @foreach ($AllTable as $Customer)
                            <div class="col-md-6  text-left mb-1">
                                <a href="{{url('Orders/edit/'.$Customer->id)}}" class="text-reset">{{$Customer->cname}}</a> <br>
                            </div>
                            <div class="col-md-6  text-right mb-1">
                                <form action="{{url('Orders/deleteOrder/'.$Customer->id)}}" method="post">
                                    @csrf
                                    <a  href="{{url('Orders/edit/'.$Customer->id)}}" class='text-reset mr-2'><i class="fa fa-edit icon_scale"></i></a>
                                    <button  type="submit" class=' confirm ButtonConfirm'><i class="fa fa-trash icon_scale text-danger"></i></button>
                                </form>
                            </div>
                            @endforeach
                        </div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="panel panel-default lastes lastes_yeallo">
                <div class="panel-heading panel-h">
                    <span class="plus toggle fa-pull-right">
                        <i class="fa fa-minus  "></i>


                    </span>
                    <i class="fas fa-chart-line"></i>
                    <span>Today</span>
                </div>
                <div class="panel-body panel-b">
                    <div class="row mb-1">
                        <div class="col-6 ">
                            <span><a href="{{url('Orders/totalmeter')}}" class="text-reset h5"></span>
                                Printed Today
                            </a>
                        </div>
                        <div class=" col-6 mt-2 h5">
                            {{$today}} Meters
                        </div>
                    </div>


                </div>
            </div>
        </div>



        <div class="col-md-6">
            <div class="panel panel-default lastes lastes_red">
                <div class="panel-heading panel-h">
                    <span class="plus toggle fa-pull-right">
                        <i class="fa fa-minus  "></i>
                    </span>
                    <i class="fa fa-comment"></i>
                    <span>Lastest Note From EMP</span>
                </div>
                <div class="panel-body panel-b">
                    <div class="row mb-1">
                        @foreach ($LastComment as $LastComments)
                        <div class="col-3 last_users_comment_div">
                            <i class="fa fa-user"></i>
                            <span class="last_users_comment">
                                {{$LastComments->EmpCommet}}
                            </span>
                        </div>
                        <div class="col-9 last_comment_div">
                            <div class="arrors_comment"></div>
                            <p class="last_comment">
                                {{$LastComments->comment}}
                            </p>
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




@endsection
