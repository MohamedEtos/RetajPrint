@extends('layouts.master')

@section('addOrder')
<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <form method="POST" action="{{url('Orders/Add')}}">
                @csrf
                @if (Session::has('storedone'))
                <div class="text-success smoth mt-3 " id="smoth"> {{Session::get('storedone')}}</div>
                @endif

                <div class="form-group">
                    <label for="exampleInputEmail1">Customer Name</label>
                    <input list="brow" name="cname" class="form-control">
                    <datalist id="brow">
                        @foreach ($comeData as $data)
                        <option value="{{$data->cname}}">
                        @endforeach
                    </datalist>
                    @error('cname')
                    <small id="cname" class="form-text  text-danger">{{'* '.$message}}</small>
                    @enderror
                </div>



                <div class="form-group">
                    <label for="exampleInputEmail1">Full Meter</label>
                    <input name="meter" type="number" class="form-control" id="meter" aria-describedby="meter" placeholder="Full meter">
                    @error('meter')
                    <small id="meter" class="form-text  text-danger">{{'* '.$message}}</small>
                    @enderror
                </div>

                <button type="submit" class="btn btn-primary btn_smoth">Save Data</button>

            </form>

        </div>

    </div>
</div>

@endsection
