<?php

namespace App\Http\Controllers;

use App\Models\comment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class CommentController extends Controller
{
    public function NewComment (){
        return view('NewComment');
      }
      public function StoreComment (Request $request){
        $request->validate([
        'newcomment'=>'required|min:5'
        ]);

        comment::create([
            'comment'=>$request->newcomment,
            'EmpCommet'=>Auth::User()->name
        ]);
        return redirect()->back()->with('CommentSuc','The Comment Has Been Added');
      }
}
